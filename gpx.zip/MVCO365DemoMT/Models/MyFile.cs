﻿
namespace MVCO365Demo.Models
{
    public class MyFile
    {
        public string Name { get; set; }
    }
}
﻿
namespace MVCO365Demo.Models
{
    public class MyContact
    {
        public string Name { get; set; }
    }
}

﻿/// <autosync enabled="true" />
/// <reference path="bootstrap.js" />
/// <reference path="jquery-2.1.1.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="modernizr-2.8.3.js" />
/// <reference path="respond.js" />
/// <reference path="respond.matchmedia.addlistener.js" />
